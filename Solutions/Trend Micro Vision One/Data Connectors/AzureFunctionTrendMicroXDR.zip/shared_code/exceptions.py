class GeneralException(Exception):
    pass